using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Linq;

public class SubGoal{
    public Dictionary<string,int> sgoals;
    public bool remove;

    public SubGoal(string s,int i,bool r ){
        sgoals = new Dictionary<string,int>();
        sgoals.Add(s,i);
        remove = r;
    }
}

public class GAgent : MonoBehaviour
{
    public List<GAction> actions = new List<GAction>();
    public Dictionary<SubGoal,int> goals = new Dictionary<SubGoal,int>();

    GPlanner planner; 
    Queue<GAction> actionQueue;
    public GAction currentAction;
    SubGoal currentGoal;

    // Start is called before the first frame update
    public void Start()
    {
        GAction[] acts  =this.GetComponents<GAction>();
        foreach(GAction a in acts){
            actions.Add(a);
        }
    }
    
    bool invoked = false;
    void CompleteAction(){
        currentAction.running = false;
        currentAction.PostPerform();
        invoked = false;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        bool we_are_in_middle_of_performing_an_action = currentAction !=null && currentAction.running;
        if(we_are_in_middle_of_performing_an_action){
            bool the_agent_is_at_where_the_action_need_to_be_performed = currentAction.agent.hasPath && currentAction.agent.remainingDistance <1f;
            if(the_agent_is_at_where_the_action_need_to_be_performed){

                bool action_completion_squence_has_not_been_initiated = !invoked;
                if(action_completion_squence_has_not_been_initiated){
                    Invoke("CompleteAction",currentAction.duration);
                    invoked = true;
                }
            }
            return;
        }

        bool agent_currently_has_no_plan_to_work_on = planner == null || actionQueue == null; 
        
        if(agent_currently_has_no_plan_to_work_on){
            
            planner = new GPlanner();

            //ordering gaols by the order of importnace
            var sortedGoals = from entry in goals orderby entry.Value descending select entry;
            
            //trying to find a plan for a goal that is possible to achive in sortedGoals
            foreach(KeyValuePair<SubGoal,int> sg in sortedGoals){
                actionQueue = planner.plan(actions,sg.Key.sgoals,null);
                
                bool a_plan_is_found_for_current_goal = actionQueue !=null;
                if(a_plan_is_found_for_current_goal){
                    currentGoal = sg.Key;
                    break;
                }
            }
        }

        bool there_is_no_more_actions_to_be_performed  = actionQueue !=null && actionQueue.Count ==0 ;
        if(there_is_no_more_actions_to_be_performed){
            if(currentGoal.remove){
                goals.Remove(currentGoal);

            }
            planner = null;
        }

        bool there_is_more_actions_to_be_performed = actionQueue !=null && actionQueue.Count >0;
        if(there_is_more_actions_to_be_performed){
            currentAction = actionQueue.Dequeue();
            if (currentAction.PrePerform()){
                if(currentAction.target ==null && currentAction.targetTag !=""){
                    currentAction.target = GameObject.FindWithTag(currentAction.targetTag);
                }
                if(currentAction.target !=null){

                    currentAction.running = true;
                    currentAction.agent.SetDestination(currentAction.target.transform.position);
                }
            }else{
                actionQueue = null;
            }
        }
    }
}
